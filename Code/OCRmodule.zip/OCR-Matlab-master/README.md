# OCR-Matlab
Optical Character Reader based on simple methods in Matlab
